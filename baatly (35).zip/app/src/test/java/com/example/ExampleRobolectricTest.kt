package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.BillingEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun read_app_name_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Baatly", appName)
    }

    @Test
    fun test_billing_engine_call_calculations() {
        // 0 balance -> 0 max duration
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(0))
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(5))

        // 6 coins -> 60s (1 min)
        assertEquals(60, BillingEngine.calculateMaxCallDurationSeconds(6))

        // 18 coins -> 180s (3 min)
        assertEquals(180, BillingEngine.calculateMaxCallDurationSeconds(18))

        // User coins: 6 coins per started minute
        assertEquals(0, BillingEngine.calculateUserCallCostCoins(0))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(1))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(59))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(60))
        assertEquals(12, BillingEngine.calculateUserCallCostCoins(61))
    }

    @Test
    fun test_forbidden_number_moderation() {
        assertTrue(BillingEngine.containsForbiddenNumberContent("call me at 9876543210"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("my number is 9 8 7 6 5 4 3 2 1 0"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("reach me on nine eight seven six five four three two one zero"))
        assertFalse(BillingEngine.containsForbiddenNumberContent("Hello, how are you? Let's chat."))
    }
}
