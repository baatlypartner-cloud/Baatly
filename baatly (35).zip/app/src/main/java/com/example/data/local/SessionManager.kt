package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.UserProfile
import com.example.data.model.WalletInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("baatly_session_prefs", Context.MODE_PRIVATE)

    private val _accessToken = MutableStateFlow<String?>(prefs.getString(KEY_TOKEN, null))
    val accessToken: StateFlow<String?> = _accessToken.asStateFlow()

    private val _userId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _wallet = MutableStateFlow<WalletInfo?>(null)
    val wallet: StateFlow<WalletInfo?> = _wallet.asStateFlow()

    val isLoggedIn: Boolean
        get() = !_accessToken.value.isNullOrBlank()

    fun saveSession(token: String, userId: String, profile: UserProfile? = null) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER_ID, userId)
            .apply()
        _accessToken.value = token
        _userId.value = userId
        if (profile != null) {
            _currentUser.value = profile
        }
    }

    fun updateProfile(profile: UserProfile) {
        _currentUser.value = profile
    }

    fun updateWallet(wallet: WalletInfo) {
        _wallet.value = wallet
    }

    fun clearSession() {
        prefs.edit().clear().apply()
        _accessToken.value = null
        _userId.value = null
        _currentUser.value = null
        _wallet.value = null
    }

    companion object {
        private const val KEY_TOKEN = "jwt_access_token"
        private const val KEY_USER_ID = "auth_user_id"
    }
}
