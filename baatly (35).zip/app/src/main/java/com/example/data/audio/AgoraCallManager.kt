package com.example.data.audio

import android.content.Context
import android.media.AudioManager
import android.util.Log
import com.example.data.model.AgoraTokenResponse
import com.example.data.network.SupabaseConfig
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AgoraCallManager(private val context: Context?) {

    private val tag = "AgoraCallManager"
    private var rtcEngine: RtcEngine? = null
    private val audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isSpeakerOn = MutableStateFlow(true)
    val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

    private val _isInChannel = MutableStateFlow(false)
    val isInChannel: StateFlow<Boolean> = _isInChannel.asStateFlow()

    private val _remoteUserJoined = MutableStateFlow(false)
    val remoteUserJoined: StateFlow<Boolean> = _remoteUserJoined.asStateFlow()

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.d(tag, "Joined Agora channel: $channel, uid: $uid")
            _isInChannel.value = true
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.d(tag, "Remote user joined: $uid")
            _remoteUserJoined.value = true
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            Log.d(tag, "Remote user offline: $uid, reason: $reason")
            _remoteUserJoined.value = false
        }

        override fun onLeaveChannel(stats: RtcStats?) {
            Log.d(tag, "Left Agora channel")
            _isInChannel.value = false
            _remoteUserJoined.value = false
        }

        override fun onError(err: Int) {
            Log.e(tag, "Agora RTC error: $err")
        }
    }

    private fun setupRtcEngine() {
        if (rtcEngine != null) return
        val appContext = context?.applicationContext ?: context ?: run {
            Log.w(tag, "Context is null, skipping Agora setup")
            return
        }
        val appId = SupabaseConfig.agoraAppId
        if (appId.isBlank()) {
            Log.w(tag, "Agora App ID is empty, skipping Agora setup")
            return
        }
        try {
            val config = RtcEngineConfig().apply {
                mContext = appContext
                mAppId = appId
                mEventHandler = rtcEventHandler
                mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
            }
            rtcEngine = RtcEngine.create(config)?.apply {
                enableAudio()
                setEnableSpeakerphone(true)
            }
        } catch (e: Throwable) {
            Log.e(tag, "Failed to initialize Agora RtcEngine: ${e.message}", e)
        }
    }

    fun joinChannel(tokenResponse: AgoraTokenResponse, channelName: String) {
        if (rtcEngine == null) {
            setupRtcEngine()
        }

        try {
            val options = ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
            }

            val uid = tokenResponse.uid?.toInt() ?: 0
            val token = tokenResponse.token.takeIf { !it.isNullOrBlank() }

            rtcEngine?.joinChannel(token, channelName, uid, options)
            setSpeakerphoneOn(true)
        } catch (e: Exception) {
            Log.e(tag, "Error joining Agora channel: ${e.message}", e)
        }
    }

    fun leaveChannel() {
        try {
            rtcEngine?.leaveChannel()
        } catch (e: Exception) {
            Log.e(tag, "Error leaving channel: ${e.message}", e)
        }
        _isInChannel.value = false
        _remoteUserJoined.value = false
        audioManager?.mode = AudioManager.MODE_NORMAL
    }

    fun toggleMute() {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        try {
            rtcEngine?.muteLocalAudioStream(newMute)
        } catch (e: Exception) {
            Log.e(tag, "Error muting: ${e.message}")
        }
    }

    fun toggleSpeaker() {
        val newSpeaker = !_isSpeakerOn.value
        setSpeakerphoneOn(newSpeaker)
    }

    fun setSpeakerphoneOn(on: Boolean) {
        _isSpeakerOn.value = on
        try {
            rtcEngine?.setEnableSpeakerphone(on)
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = on
        } catch (_: Exception) {}
    }

    fun destroy() {
        try {
            leaveChannel()
            RtcEngine.destroy()
            rtcEngine = null
        } catch (e: Exception) {
            Log.e(tag, "Error destroying RtcEngine: ${e.message}")
        }
    }
}

