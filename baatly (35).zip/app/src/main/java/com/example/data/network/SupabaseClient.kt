package com.example.data.network

import com.example.data.local.SessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class SupabaseClient(private val sessionManager: SessionManager) {

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun getBaseHeaders(): Map<String, String> {
        val headers = mutableMapOf(
            "apikey" to SupabaseConfig.publishableKey,
            "Content-Type" to "application/json"
        )
        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    suspend fun get(url: String, params: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
        val urlBuilder = StringBuilder(url)
        if (params.isNotEmpty()) {
            urlBuilder.append(if (url.contains("?")) "&" else "?")
            params.entries.forEachIndexed { index, entry ->
                if (index > 0) urlBuilder.append("&")
                urlBuilder.append(entry.key).append("=").append(entry.value)
            }
        }

        val requestBuilder = Request.Builder().url(urlBuilder.toString())
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun post(url: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun patch(url: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val requestBuilder = Request.Builder().url(url).patch(requestBody)
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }
        requestBuilder.addHeader("Prefer", "return=representation")

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun rpc(rpcName: String, params: Map<String, Any?> = emptyMap()): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/rest/v1/rpc/$rpcName"
        val jsonObject = JSONObject()
        params.forEach { (k, v) ->
            if (v == null) {
                jsonObject.put(k, JSONObject.NULL)
            } else {
                jsonObject.put(k, v)
            }
        }
        val requestBody = jsonObject.toString().toRequestBody(jsonMediaType)

        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun callEdgeFunction(functionName: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/functions/v1/$functionName"
        val requestBody = jsonBody.toRequestBody(jsonMediaType)

        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun uploadFile(bucket: String, path: String, file: File, mimeType: String): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/$bucket/$path"
        val requestBody = RequestBody.create(mimeType.toMediaType(), file)

        val requestBuilder = Request.Builder()
            .url(url)
            .post(requestBody)
        getBaseHeaders().forEach { (k, v) ->
            if (k != "Content-Type") {
                requestBuilder.addHeader(k, v)
            }
        }
        requestBuilder.addHeader("Content-Type", mimeType)

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.isSuccessful) {
            "$bucket/$path"
        } else {
            handleResponse(response)
        }
    }

    suspend fun createSignedUrl(bucket: String, path: String, expiresInSeconds: Int = 3600): String = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/sign/$bucket/$cleanPath"
        val payload = JSONObject().apply { put("expiresIn", expiresInSeconds) }
        val responseStr = post(url, payload.toString())
        val json = JSONObject(responseStr)
        val signedUrlPath = json.optString("signedURL", "")
        if (signedUrlPath.startsWith("http")) {
            signedUrlPath
        } else {
            "${SupabaseConfig.supabaseUrl}$signedUrlPath"
        }
    }

    private fun handleResponse(response: Response): String {
        val responseBody = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val userFriendlyError = parseFriendlyError(response.code, responseBody)
            throw SupabaseException(userFriendlyError, response.code, responseBody)
        }
        return responseBody
    }

    private fun parseFriendlyError(code: Int, body: String): String {
        val lower = body.lowercase()
        return when {
            code == 401 || code == 400 && lower.contains("invalid login") || lower.contains("invalid_credentials") ->
                "Invalid User ID or Password. Please check your credentials."
            lower.contains("user_id already exists") || lower.contains("duplicate key") && lower.contains("user_id") ->
                "This User ID is already taken."
            lower.contains("invalid referral code") || lower.contains("referral code not found") ->
                "Invalid referral code."
            lower.contains("insufficient") || lower.contains("not enough coins") || lower.contains("balance") ->
                "You don't have enough coins."
            lower.contains("host is not available") || lower.contains("partner not online") ->
                "This host is not available right now."
            lower.contains("blocked") || lower.contains("cannot message") ->
                "You cannot message this host."
            lower.contains("number") || lower.contains("contact") || lower.contains("forbidden") ->
                "Number or contact-sharing content is not allowed."
            code == 404 -> "Requested item not found."
            code >= 500 -> "Server temporarily busy. Please try again."
            else -> {
                try {
                    val json = JSONObject(body)
                    json.optString("message", json.optString("error_description", "Operation failed. Please try again."))
                } catch (_: Exception) {
                    "Operation failed. Please try again."
                }
            }
        }
    }
}

class SupabaseException(
    override val message: String,
    val statusCode: Int,
    val rawBody: String
) : Exception(message)
