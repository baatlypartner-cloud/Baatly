package com.example.ui.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*

@Composable
fun AuthScreen(viewModel: BaatlyViewModel) {
    var isSignUp by remember { mutableStateOf(false) }

    // Sign Up Fields
    var displayName by remember { mutableStateOf("") }
    var userId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var mobileNumber by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }

    // Sign In Fields
    var signInUserId by remember { mutableStateOf("") }
    var signInPassword by remember { mutableStateOf("") }
    var signInPasswordVisible by remember { mutableStateOf(false) }

    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()
    val userIdAvailable by viewModel.userIdAvailable.collectAsState()

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Branding Logo
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(PrimaryLavender),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Chat,
                    contentDescription = "Baatly",
                    tint = Color(0xFF1C1C22),
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "BAATLY",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                    color = Color.White
                )
            )

            Text(
                text = "Real Conversations • Instant Audio Calls",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary
                )
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Tab Selector: SIGN IN / SIGN UP
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(5.dp)
                ) {
                    TabButton(
                        title = "SIGN IN",
                        selected = !isSignUp,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_sign_in",
                        onClick = { isSignUp = false }
                    )
                    TabButton(
                        title = "SIGN UP",
                        selected = isSignUp,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_sign_up",
                        onClick = { isSignUp = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Error Display
            if (!authError.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DangerRed.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = "Error",
                            tint = DangerRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = authError ?: "",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                        )
                    }
                }
            }

            if (isSignUp) {
                // SIGN UP FORM
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Name") },
                    leadingIcon = {
                        Icon(Icons.Outlined.Person, contentDescription = null, tint = TextSecondary)
                    },
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signup_display_name")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = userId,
                    onValueChange = {
                        userId = it.lowercase().trim()
                        viewModel.checkUserIdAvailability(userId)
                    },
                    label = { Text("User ID (e.g. rahul123)") },
                    leadingIcon = {
                        Icon(Icons.Outlined.AlternateEmail, contentDescription = null, tint = TextSecondary)
                    },
                    trailingIcon = {
                        if (userIdAvailable != null) {
                            if (userIdAvailable == true) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = "Available", tint = OnlineGreen)
                            } else {
                                Icon(Icons.Filled.Cancel, contentDescription = "Taken", tint = DangerRed)
                            }
                        }
                    },
                    supportingText = {
                        Text(
                            text = if (userIdAvailable == false) "User ID already taken" else "Allowed: a-z, 0-9, dot, underscore, hyphen",
                            color = if (userIdAvailable == false) DangerRed else TextTertiary
                        )
                    },
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signup_user_id")
                )

                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = {
                        Icon(Icons.Outlined.Lock, contentDescription = null, tint = TextSecondary)
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = "Toggle password",
                                tint = TextSecondary
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signup_password")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { if (it.length <= 10) mobileNumber = it.filter { char -> char.isDigit() } },
                    label = { Text("Mobile Number (10 digits)") },
                    prefix = { Text("+91 ", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Outlined.Phone, contentDescription = null, tint = TextSecondary)
                    },
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signup_mobile")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = referralCode,
                    onValueChange = { referralCode = it.uppercase() },
                    label = { Text("Referral Code (Optional)") },
                    leadingIcon = {
                        Icon(Icons.Outlined.CardGiftcard, contentDescription = null, tint = SecondaryAmber)
                    },
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signup_referral")
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.signUp(
                            displayName = displayName,
                            userId = userId,
                            password = password,
                            mobileNumber = mobileNumber,
                            referralCode = referralCode
                        )
                    },
                    enabled = !isAuthLoading && userId.isNotBlank() && password.isNotBlank() && displayName.isNotBlank() && mobileNumber.length == 10,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryLavender,
                        contentColor = Color(0xFF1C1C22),
                        disabledContainerColor = DarkSurfaceVariant,
                        disabledContentColor = TextTertiary
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_submit_signup")
                ) {
                    if (isAuthLoading) {
                        CircularProgressIndicator(
                            color = Color(0xFF1C1C22),
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Text(
                            text = "CREATE ACCOUNT",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF1C1C22)
                        )
                    }
                }
            } else {
                // SIGN IN FORM
                OutlinedTextField(
                    value = signInUserId,
                    onValueChange = { signInUserId = it.trim() },
                    label = { Text("User ID") },
                    leadingIcon = {
                        Icon(Icons.Outlined.AlternateEmail, contentDescription = null, tint = TextSecondary)
                    },
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signin_user_id")
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = signInPassword,
                    onValueChange = { signInPassword = it },
                    label = { Text("Password") },
                    leadingIcon = {
                        Icon(Icons.Outlined.Lock, contentDescription = null, tint = TextSecondary)
                    },
                    trailingIcon = {
                        IconButton(onClick = { signInPasswordVisible = !signInPasswordVisible }) {
                            Icon(
                                imageVector = if (signInPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = "Toggle password",
                                tint = TextSecondary
                            )
                        }
                    },
                    visualTransformation = if (signInPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    colors = authTextFieldColors(),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        focusManager.clearFocus()
                        viewModel.signIn(signInUserId, signInPassword)
                    }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("signin_password")
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.signIn(signInUserId, signInPassword)
                    },
                    enabled = !isAuthLoading && signInUserId.isNotBlank() && signInPassword.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryLavender,
                        contentColor = Color(0xFF1C1C22),
                        disabledContainerColor = DarkSurfaceVariant,
                        disabledContentColor = TextTertiary
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_submit_signin")
                ) {
                    if (isAuthLoading) {
                        CircularProgressIndicator(
                            color = Color(0xFF1C1C22),
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Text(
                            text = "SIGN IN",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF1C1C22)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabButton(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) PrimaryLavender else Color.Transparent,
        modifier = modifier
            .testTag(testTag)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color(0xFF1C1C22) else TextSecondary
                )
            )
        }
    }
}

@Composable
private fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = PrimaryLavender,
    unfocusedBorderColor = DarkCardBorder,
    focusedLabelColor = PrimaryLavender,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = PrimaryLavender,
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface
)
