package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BaatlyColorScheme = darkColorScheme(
    primary = PrimaryLavender,
    onPrimary = Color(0xFF1C1C22),
    primaryContainer = PrimaryLavenderContainer,
    onPrimaryContainer = Color.White,
    secondary = SecondaryAmber,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF2E2A1B),
    onSecondaryContainer = SecondaryAmberLight,
    tertiary = AccentPurpleLight,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder,
    outlineVariant = DarkBorderSubtle,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun BaatlyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BaatlyColorScheme,
        typography = Typography,
        content = content
    )
}
