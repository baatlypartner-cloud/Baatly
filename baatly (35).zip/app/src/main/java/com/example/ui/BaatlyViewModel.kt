package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AgoraCallManager
import com.example.data.audio.AudioPlayerManager
import com.example.data.audio.AudioRecorderManager
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseAuthService
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.example.domain.BillingEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class BaatlyViewModel(application: Application) : AndroidViewModel(application) {

    val sessionManager = SessionManager(application)
    private val supabaseClient = SupabaseClient(sessionManager)
    val authService = SupabaseAuthService(supabaseClient, sessionManager)
    val dataService = SupabaseDataService(supabaseClient, sessionManager)

    val agoraCallManager = AgoraCallManager(application)
    val audioRecorderManager = AudioRecorderManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val realtimeManager = com.example.data.network.SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

    // User & Auth State
    val isLoggedIn = sessionManager.accessToken
    val currentUser = sessionManager.currentUser
    val wallet = sessionManager.wallet

    private val _isRestoringSession = MutableStateFlow(false)
    val isRestoringSession: StateFlow<Boolean> = _isRestoringSession.asStateFlow()

    private val _startupError = MutableStateFlow<String?>(null)
    val startupError: StateFlow<String?> = _startupError.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _userIdAvailable = MutableStateFlow<Boolean?>(null)
    val userIdAvailable: StateFlow<Boolean?> = _userIdAvailable.asStateFlow()

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _homeMode = MutableStateFlow(HomeMode.CALL) // CALL or CHAT
    val homeMode: StateFlow<HomeMode> = _homeMode.asStateFlow()

    // Hosts State
    private val _availablePartners = MutableStateFlow<List<PartnerProfile>>(emptyList())
    val availablePartners: StateFlow<List<PartnerProfile>> = _availablePartners.asStateFlow()

    private val _isLoadingPartners = MutableStateFlow(false)
    val isLoadingPartners: StateFlow<Boolean> = _isLoadingPartners.asStateFlow()

    private val _selectedPartner = MutableStateFlow<PartnerProfile?>(null)
    val selectedPartner: StateFlow<PartnerProfile?> = _selectedPartner.asStateFlow()

    // Call State
    private val _activeCall = MutableStateFlow<CallRecord?>(null)
    val activeCall: StateFlow<CallRecord?> = _activeCall.asStateFlow()

    private val _activeCallPartner = MutableStateFlow<PartnerProfile?>(null)
    val activeCallPartner: StateFlow<PartnerProfile?> = _activeCallPartner.asStateFlow()

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callRemainingSeconds = MutableStateFlow(0)
    val callRemainingSeconds: StateFlow<Int> = _callRemainingSeconds.asStateFlow()

    private val _callElapsedSeconds = MutableStateFlow(0)
    val callElapsedSeconds: StateFlow<Int> = _callElapsedSeconds.asStateFlow()

    private var callTimerJob: Job? = null

    // Chat State
    private val _conversations = MutableStateFlow<List<ConversationSummary>>(emptyList())
    val conversations: StateFlow<List<ConversationSummary>> = _conversations.asStateFlow()

    private val _activeConversation = MutableStateFlow<ConversationSummary?>(null)
    val activeConversation: StateFlow<ConversationSummary?> = _activeConversation.asStateFlow()

    private val _chatPartner = MutableStateFlow<PartnerProfile?>(null)
    val chatPartner: StateFlow<PartnerProfile?> = _chatPartner.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isChatBlocked = MutableStateFlow(false)
    val isChatBlocked: StateFlow<Boolean> = _isChatBlocked.asStateFlow()

    // Gifts State
    private val _gifts = MutableStateFlow<List<GiftItem>>(emptyList())
    val gifts: StateFlow<List<GiftItem>> = _gifts.asStateFlow()

    private val _showGiftSheet = MutableStateFlow(false)
    val showGiftSheet: StateFlow<Boolean> = _showGiftSheet.asStateFlow()

    private val _recentGiftAnimation = MutableStateFlow<GiftItem?>(null)
    val recentGiftAnimation: StateFlow<GiftItem?> = _recentGiftAnimation.asStateFlow()

    // Wallet & Packages State
    private val _coinPackages = MutableStateFlow<List<CoinPackage>>(emptyList())
    val coinPackages: StateFlow<List<CoinPackage>> = _coinPackages.asStateFlow()

    // Recent Calls State
    private val _recentCalls = MutableStateFlow<List<CallRecord>>(emptyList())
    val recentCalls: StateFlow<List<CallRecord>> = _recentCalls.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    // General Toast / SnackBar State
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        if (sessionManager.isLoggedIn) {
            loadInitialData()
        }
    }

    fun setScreen(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setHomeMode(mode: HomeMode) {
        _homeMode.value = mode
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun toggleGiftSheet(show: Boolean) {
        _showGiftSheet.value = show
    }

    // AUTH FLOWS
    fun checkUserIdAvailability(userId: String) {
        if (userId.length < 3) {
            _userIdAvailable.value = null
            return
        }
        viewModelScope.launch {
            val isAvail = authService.checkUserIdAvailable(userId)
            _userIdAvailable.value = isAvail
        }
    }

    fun signIn(userId: String, password: String) {
        if (userId.isBlank() || password.isBlank()) {
            _authError.value = "Please enter both User ID and Password."
            return
        }
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            val result = authService.signIn(userId, password)
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Authentication failed."
            }
        }
    }

    fun signUp(
        displayName: String,
        userId: String,
        password: String,
        mobileNumber: String,
        avatarFile: File? = null,
        referralCode: String? = null
    ) {
        val normalizedUserId = userId.trim().lowercase()

        // Validation 1: User ID
        val userIdRegex = Regex("""^[a-z0-9._-]{3,30}$""")
        if (!userIdRegex.matches(normalizedUserId)) {
            _authError.value = "User ID must be 3-30 characters (letters, numbers, '.', '_', '-')."
            return
        }

        // Validation 2: Display Name
        if (displayName.trim().isBlank()) {
            _authError.value = "Display Name is required."
            return
        }

        // Validation 3: Password
        if (password.length < 6) {
            _authError.value = "Password must be at least 6 characters."
            return
        }

        // Validation 4: Mobile Number (Indian 10-digit)
        val cleanPhone = mobileNumber.trim().replace("+91", "").replace(" ", "").replace("-", "")
        val mobileRegex = Regex("""^[6-9]\d{9}$""")
        if (!mobileRegex.matches(cleanPhone)) {
            _authError.value = "Please enter a valid 10-digit Indian mobile number."
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        viewModelScope.launch {
            val result = authService.signUp(
                userId = normalizedUserId,
                password = password,
                displayName = displayName.trim(),
                mobileNumber = cleanPhone,
                avatarFile = avatarFile,
                referralCode = referralCode?.trim().takeIf { !it.isNullOrBlank() }
            )
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Sign up failed."
            }
        }
    }

    fun signOut() {
        authService.signOut()
        _currentScreen.value = Screen.AUTH
    }

    fun retryStartup() {
        _startupError.value = null
        if (sessionManager.isLoggedIn) {
            loadInitialData()
        }
    }

    fun loadInitialData() {
        _isRestoringSession.value = true
        _startupError.value = null
        viewModelScope.launch {
            try {
                authService.fetchCurrentUserProfile()
                dataService.fetchWallet()
                refreshPartners()
                refreshGifts()
                refreshCoinPackages()
                refreshConversations()
                refreshRecentCalls()
                refreshNotifications()
            } catch (e: Exception) {
                _startupError.value = e.message ?: "Failed to load session data"
            } finally {
                _isRestoringSession.value = false
            }
        }
    }

    fun refreshPartners() {
        _isLoadingPartners.value = true
        viewModelScope.launch {
            dataService.getAvailablePartners().onSuccess {
                _availablePartners.value = it
            }
            _isLoadingPartners.value = false
        }
    }

    fun refreshGifts() {
        viewModelScope.launch {
            dataService.fetchGifts().onSuccess {
                _gifts.value = it
            }
        }
    }

    fun refreshCoinPackages() {
        viewModelScope.launch {
            dataService.fetchCoinPackages().onSuccess {
                _coinPackages.value = it
            }
        }
    }

    fun refreshConversations() {
        viewModelScope.launch {
            dataService.fetchConversations().onSuccess {
                _conversations.value = it
            }
        }
    }

    fun refreshRecentCalls() {
        viewModelScope.launch {
            dataService.fetchRecentCalls().onSuccess {
                _recentCalls.value = it
            }
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch {
            dataService.fetchNotifications().onSuccess {
                _notifications.value = it
            }
        }
    }

    fun refreshWallet() {
        viewModelScope.launch {
            dataService.fetchWallet()
        }
    }

    // HOST ACTIONS
    fun openHostProfile(partner: PartnerProfile) {
        _selectedPartner.value = partner
        _currentScreen.value = Screen.HOST_PROFILE
    }

    fun toggleFollowHost(partner: PartnerProfile) {
        viewModelScope.launch {
            val isNowFollowing = !partner.isFollowing
            if (isNowFollowing) {
                dataService.followHost(partner.id)
            } else {
                dataService.unfollowHost(partner.id)
            }
            // Update local state
            _selectedPartner.value = _selectedPartner.value?.copy(
                isFollowing = isNowFollowing,
                followersCount = if (isNowFollowing) partner.followersCount + 1 else maxOf(0, partner.followersCount - 1)
            )
            _availablePartners.value = _availablePartners.value.map {
                if (it.id == partner.id) it.copy(isFollowing = isNowFollowing) else it
            }
        }
    }

    // CALL FLOW
    private var callPollerJob: Job? = null

    fun requestCall(partner: PartnerProfile) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.USER_COINS_PER_MINUTE) {
            _userMessage.value = "You don't have enough coins. Please top up your wallet."
            _currentScreen.value = Screen.WALLET
            return
        }

        val estimatedMaxSeconds = BillingEngine.calculateMaxCallDurationSeconds(currentBalance)
        _activeCallPartner.value = partner
        _callState.value = CallState.REQUESTING
        _callRemainingSeconds.value = estimatedMaxSeconds
        _callElapsedSeconds.value = 0
        _currentScreen.value = Screen.ACTIVE_CALL

        viewModelScope.launch {
            val result = dataService.requestCall(partner.id)
            result.onSuccess { callRecord ->
                _activeCall.value = callRecord
                _callState.value = CallState.RINGING
                startCallStatePoller(callRecord, partner)
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Could not connect call."
                endCall()
            }
        }
    }

    private fun startCallStatePoller(initialCall: CallRecord, partner: PartnerProfile) {
        callPollerJob?.cancel()
        callPollerJob = viewModelScope.launch {
            var currentCall = initialCall
            var joinedAgora = false

            while (_callState.value != CallState.ENDED && _callState.value != CallState.IDLE) {
                delay(1500)
                val statusResult = dataService.getCallRecord(currentCall.id)
                if (statusResult.isSuccess) {
                    val updated = statusResult.getOrThrow()
                    currentCall = updated
                    _activeCall.value = updated

                    when (updated.status.lowercase()) {
                        "ringing" -> {
                            if (_callState.value != CallState.RINGING) {
                                _callState.value = CallState.RINGING
                            }
                        }
                        "accepted", "connected" -> {
                            if (!joinedAgora) {
                                joinedAgora = true
                                val channelName = updated.agoraChannelId ?: "baatly_call_${updated.id}"
                                dataService.getAgoraToken(channelName).onSuccess { tokenResp ->
                                    agoraCallManager.joinChannel(tokenResp, channelName)
                                }
                                dataService.updateCallState(updated.id, "connected")
                                _callState.value = CallState.CONNECTED

                                val maxSec = updated.maxDurationSeconds
                                    ?.takeIf { it > 0 }
                                    ?: BillingEngine.calculateMaxCallDurationSeconds(wallet.value?.balance ?: 0)
                                startCallCountdown(maxSec)
                            }
                        }
                        "completed", "ended", "cancelled", "rejected", "missed" -> {
                            val statusLower = updated.status.lowercase()
                            val msg = when (statusLower) {
                                "rejected" -> "Host declined the call."
                                "missed" -> "No answer. Call was missed."
                                else -> "Call ended."
                            }
                            _userMessage.value = msg
                            handleCallTerminated(statusLower)
                            break
                        }
                    }
                }
            }
        }
    }

    private fun handleCallTerminated(status: String) {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        if (call != null && status != "missed" && status != "rejected" && status != "cancelled") {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        } else {
            viewModelScope.launch {
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    private fun startCallCountdown(maxDurationSec: Int) {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            var remaining = maxDurationSec
            var elapsed = 0
            _callRemainingSeconds.value = remaining
            _callElapsedSeconds.value = elapsed

            while (remaining > 0 && _callState.value == CallState.CONNECTED) {
                delay(1000)
                remaining--
                elapsed++
                _callRemainingSeconds.value = remaining
                _callElapsedSeconds.value = elapsed
            }
            if (remaining <= 0 && _callState.value == CallState.CONNECTED) {
                _userMessage.value = "Call ended: Maximum duration reached based on your coin balance."
                endCall()
            }
        }
    }

    fun endCall() {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        if (call != null) {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    // CHAT FLOW
    fun openChatWithHost(partner: PartnerProfile) {
        _chatPartner.value = partner
        _isChatBlocked.value = false
        _currentScreen.value = Screen.DIRECT_CHAT

        viewModelScope.launch {
            dataService.startChatWithHost(partner.id).onSuccess { convId ->
                _activeConversation.value = ConversationSummary(
                    id = convId,
                    partnerId = partner.id,
                    partner = partner
                )
                loadMessages(convId)
                subscribeToChatRealtime(convId)
            }
        }
    }

    fun openConversation(conversation: ConversationSummary) {
        _activeConversation.value = conversation
        _chatPartner.value = conversation.partner
        _isChatBlocked.value = false
        _currentScreen.value = Screen.DIRECT_CHAT
        loadMessages(conversation.id)
        subscribeToChatRealtime(conversation.id)
    }

    private fun subscribeToChatRealtime(conversationId: String) {
        realtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onNewMessage = { newMsg -> onRealtimeMessageReceived(newMsg) },
            onResync = { loadMessages(conversationId) }
        )
    }

    private fun onRealtimeMessageReceived(newMsg: ChatMessage) {
        val currentList = _messages.value
        if (currentList.none { it.id == newMsg.id }) {
            _messages.value = currentList + newMsg
        }
    }

    fun refreshCurrentChat() {
        val convId = _activeConversation.value?.id ?: return
        val partnerId = _chatPartner.value?.id
        viewModelScope.launch {
            loadMessages(convId)
            if (!partnerId.isNullOrBlank()) {
                dataService.getHostProfile(partnerId).onSuccess {
                    _chatPartner.value = it
                }
            }
            subscribeToChatRealtime(convId)
        }
    }

    fun closeChatScreen() {
        realtimeManager.unsubscribe()
        audioPlayerManager.stop()
        _messages.value = emptyList()
        _activeConversation.value = null
        _chatPartner.value = null
        _currentScreen.value = Screen.CHAT_LIST
    }

    private fun loadMessages(conversationId: String) {
        viewModelScope.launch {
            dataService.fetchMessages(conversationId).onSuccess { fetchedList ->
                // Deduplicate and merge with current list
                val existingIds = _messages.value.map { it.id }.toSet()
                val merged = _messages.value + fetchedList.filter { it.id !in existingIds }
                _messages.value = if (_messages.value.isEmpty()) fetchedList else merged.distinctBy { it.id }
            }
        }
    }

    fun playVoiceMessage(mediaUrl: String) {
        viewModelScope.launch {
            val playableUrl = dataService.getSignedMediaUrl(mediaUrl, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
            audioPlayerManager.play(playableUrl)
        }
    }

    fun sendTextMessage(content: String, onResult: ((Boolean) -> Unit)? = null) {
        val trimmed = content.trim()
        if (trimmed.isBlank()) return

        // Contact Number Moderation check
        if (BillingEngine.containsForbiddenNumberContent(trimmed)) {
            _userMessage.value = "Number or contact-sharing content is not allowed."
            onResult?.invoke(false)
            return
        }

        val partner = _chatPartner.value
        if (partner == null) {
            _userMessage.value = "Host not found. Please re-open the chat."
            onResult?.invoke(false)
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            onResult?.invoke(false)
            return
        }

        viewModelScope.launch {
            // Resolve or initialize conversation ID if missing
            var convId = _activeConversation.value?.id
            if (convId.isNullOrBlank()) {
                val startRes = dataService.startChatWithHost(partner.id)
                if (startRes.isSuccess) {
                    convId = startRes.getOrNull()
                    if (!convId.isNullOrBlank()) {
                        _activeConversation.value = ConversationSummary(
                            id = convId,
                            partnerId = partner.id,
                            partner = partner
                        )
                        subscribeToChatRealtime(convId)
                    }
                } else {
                    val err = startRes.exceptionOrNull()?.message ?: "Could not start chat conversation."
                    _userMessage.value = err
                    onResult?.invoke(false)
                    return@launch
                }
            }

            if (convId.isNullOrBlank()) {
                _userMessage.value = "Failed to open conversation."
                onResult?.invoke(false)
                return@launch
            }

            val sendResult = dataService.sendMessage(
                conversationId = convId,
                receiverId = partner.id,
                messageType = "text",
                content = trimmed
            )

            sendResult.onSuccess { newMsg ->
                val currentList = _messages.value
                if (currentList.none { it.id == newMsg.id }) {
                    _messages.value = currentList + newMsg
                }
                dataService.fetchWallet()
                onResult?.invoke(true)
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send message."
                onResult?.invoke(false)
            }
        }
    }

    fun sendImageMessage(file: File) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = false).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "image",
                    mediaUrl = mediaUrl
                ).onSuccess { newMsg ->
                    if (_messages.value.none { it.id == newMsg.id }) {
                        _messages.value = _messages.value + newMsg
                    }
                    dataService.fetchWallet()
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload image."
            }
        }
    }

    fun sendVoiceMessage(file: File, durationSec: Int) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = true).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "voice",
                    mediaUrl = mediaUrl,
                    mediaDurationSeconds = durationSec
                ).onSuccess { newMsg ->
                    if (_messages.value.none { it.id == newMsg.id }) {
                        _messages.value = _messages.value + newMsg
                    }
                    dataService.fetchWallet()
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload voice note."
            }
        }
    }

    fun sendGift(gift: GiftItem, targetPartnerId: String? = null, conversationId: String? = null, callId: String? = null) {
        val partnerId = targetPartnerId
            ?: _chatPartner.value?.id
            ?: _activeCallPartner.value?.id
            ?: _selectedPartner.value?.id
            ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < gift.coinPrice) {
            _userMessage.value = "You don't have enough coins to send ${gift.name}."
            return
        }

        viewModelScope.launch {
            dataService.sendGift(
                giftId = gift.id,
                receiverId = partnerId,
                conversationId = conversationId ?: _activeConversation.value?.id,
                callId = callId ?: _activeCall.value?.id
            ).onSuccess {
                _userMessage.value = "Sent ${gift.name} successfully!"
                _recentGiftAnimation.value = gift
                _showGiftSheet.value = false
                dataService.fetchWallet()
                // If in active chat, append gift message
                if (_activeConversation.value != null) {
                    val giftMsg = ChatMessage(
                        id = java.util.UUID.randomUUID().toString(),
                        conversationId = _activeConversation.value!!.id,
                        senderId = currentUser.value?.id ?: "",
                        receiverId = partnerId,
                        messageType = "gift",
                        giftId = gift.id,
                        gift = gift,
                        createdAt = "Just now"
                    )
                    if (_messages.value.none { it.id == giftMsg.id }) {
                        _messages.value = _messages.value + giftMsg
                    }
                }
                delay(3000)
                _recentGiftAnimation.value = null
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send gift."
            }
        }
    }

    fun clearCurrentConversation() {
        val conv = _activeConversation.value ?: return
        viewModelScope.launch {
            dataService.clearMyConversation(conv.id).onSuccess {
                _messages.value = emptyList()
                _userMessage.value = "Chat cleared."
            }
        }
    }

    fun blockCurrentHost(reason: String = "User requested block") {
        val partner = _chatPartner.value ?: return
        viewModelScope.launch {
            dataService.blockUser(partner.id, reason).onSuccess {
                _isChatBlocked.value = true
                _userMessage.value = "Host blocked. You can no longer send messages."
            }
        }
    }

    // TOP UP (Server-authoritative flow prepared)
    fun purchaseCoinPackage(pkg: CoinPackage) {
        _userMessage.value = "Payment checkout for ${pkg.coins} Coins (₹${pkg.priceInr.toInt()}) prepared."
    }

    override fun onCleared() {
        super.onCleared()
        callTimerJob?.cancel()
        realtimeManager.destroy()
        agoraCallManager.destroy()
        audioPlayerManager.stop()
        audioRecorderManager.release()
    }
}

enum class Screen {
    AUTH,
    HOME,
    HOST_PROFILE,
    ACTIVE_CALL,
    DIRECT_CHAT,
    BAATLY_SYSTEM_CHAT,
    CHAT_LIST,
    WALLET,
    RECENT_CALLS,
    PROFILE,
    NOTIFICATIONS
}

enum class HomeMode {
    CALL,
    CHAT
}

enum class CallState {
    IDLE,
    REQUESTING,
    RINGING,
    CONNECTED,
    ENDED
}
