package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Elegant Dark Background & Surface Palette
val DarkBackground = Color(0xFF0C0C0E)
val DarkSurface = Color(0xFF18181F)
val DarkSurfaceVariant = Color(0xFF1C1C22)
val DarkNavBackground = Color(0xFF14141A)
val DarkCardBorder = Color(0xFF23232A)
val DarkBorderSubtle = Color(0xFF2D2D35)

// Elegant Lavender & Indigo Accents
val PrimaryLavender = Color(0xFFC2C1FF)
val PrimaryLavenderContainer = Color(0xFF3F3F64)
val PrimaryLavenderDark = Color(0xFF2D2D4A)

// Retain aliases for existing references while matching the Elegant Dark palette
val PrimaryCoral = Color(0xFFC2C1FF)
val PrimaryCoralLight = Color(0xFFDEDDFF)
val PrimaryCoralDark = Color(0xFF3F3F64)

val SecondaryAmber = Color(0xFFFFD54F)
val SecondaryAmberLight = Color(0xFFFFF0B3)

val AccentPurple = Color(0xFF4F4F7A)
val AccentPurpleLight = Color(0xFFC2C1FF)

// Text Colors
val TextPrimary = Color(0xFFE2E2E6)
val TextSecondary = Color(0xFFA1A1AA)
val TextTertiary = Color(0xFF71717A)

// Status & Action Colors
val OnlineGreen = Color(0xFF4ADE80)
val OfflineGray = Color(0xFF52525B)
val DangerRed = Color(0xFFFF5252)

// Compatibility Aliases
val DarkCard = DarkSurface
val NeonPink = PrimaryLavender
val TextMuted = TextSecondary

// Gradients
val PrimaryGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFC2C1FF), Color(0xFF8B88E8), Color(0xFF4F4F7A))
)

val CardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF18181F), Color(0xFF14141A))
)

val HeroHeaderGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF1C1C28), Color(0xFF0C0C0E))
)

val HostAvatarGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF4F4F7A), Color(0xFF2D2D4A))
)

